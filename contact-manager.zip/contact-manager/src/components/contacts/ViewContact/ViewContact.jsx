import React from 'react'

const ViewContact = () => {
  return (
    <div>
      <h1>WELCOME TO VIEW CONTACT</h1>
    </div>
  )
}

export default ViewContact
