import React from 'react'

const EditContact = () => {
  return (
    <div>
        <h1>WELCOME TO EDIT CONTACT</h1>
    </div>
  )
}

export default EditContact
