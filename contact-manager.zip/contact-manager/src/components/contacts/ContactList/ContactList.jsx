import React from 'react'
import { Link } from 'react-router-dom'

const ContactList = () => {
  return (
    <>
        <section className='contact-search p-3'>
            <div className="container">
                <div className="grid">
                    <div className="row">
                        <p className='h3'>Contact Manager <Link to={'/contacts/add'}><button className='btn btn-primary'><i className='fa fa-plus-circle me-2'/>New</button></Link></p>
                        <p className='fst-italic'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit quisquam vel unde vitae laborum harum modi cupiditate rerum perferendis voluptates.</p>
                    </div>
                    <div className="row">
                        <div className="col-md-6">
                            <form action="" className='row'>
                                <div className='col mb-2'>
                                    <input type="text" placeholder='Search Names' className='form-control' />
                                </div>
                                <div className="col mb-2">
                                    <input type="submit" className='btn btn-outline-dark' value={"Search"} />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <section className='contact-card'>
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <div className="row d-flex align-items-center  ">
                                    <div className="col-md-4">
                                        <img src="https://cdn0.iconfinder.com/data/icons/20-flat-icons/128/user.png" className='contact-img' alt="" />
                                    </div>
                                    <div className="col-md-7">
                                        <ul className='list-group'>
                                            <li className='list-group-item list-group-item-action'>Name : <span className='fw-bold'>Shubham</span></li>
                                            <li className='list-group-item list-group-item-action'>Contact : <span className='fw-bold'>9874561230</span></li>
                                            <li className='list-group-item list-group-item-action'>Email : <span className='fw-bold'>shubham@gmail.com</span></li>
                                        </ul>
                                    </div>
                                    <div className="col-md-1 d-flex flex-column align-center p-1">
                                        <Link to={'/contact/view/:contactId'} className='btn btn-warning my-1'><i className='fa fa-eye'/></Link>
                                        <Link to={'/contacts/edit/:contactId'} className='btn btn-primary '><i className='fa fa-edit'/></Link>
                                        <button  className='btn btn-danger my-1'><i className='fa fa-trash'/></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="card">
                            <div className="card-body">
                                <div className="row d-flex align-items-center ">
                                    <div className="col-md-4">
                                        <img src="https://cdn0.iconfinder.com/data/icons/20-flat-icons/128/user.png" className='contact-img' alt="" />
                                    </div>
                                    <div className="col-md-7">
                                        <ul className='list-group '>
                                            <li className='list-group-item list-group-item-action'>Name : <span className='fw-bold'>Shubham</span></li>
                                            <li className='list-group-item list-group-item-action'>Contact : <span className='fw-bold'>9874561230</span></li>
                                            <li className='list-group-item list-group-item-action'>Email : <span className='fw-bold'>shubham@gmail.com</span></li>
                                        </ul>
                                    </div>
                                    <div className="col-md-1 d-flex flex-column align-center p-1">
                                        <Link to={'/contact/view/:contactId'} className='btn btn-warning my-1'><i className='fa fa-eye'/></Link>
                                        <Link to={'./contact/edit/:contactId'} className='btn btn-primary '><i className='fa fa-edit'/></Link>
                                        <Link  className='btn btn-danger my-1'><i className='fa fa-trash'/></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </>
  )
}

export default ContactList
